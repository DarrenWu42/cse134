Smooth scrolling:
    Adapted a script that allows for smooth scrolling to different sections of the website.

Clean up CSS:
    Behind the scenes I did some cleaning up of the CSS file to enable better modularity. I created new classes for each section of the portfolio and used grey section and white section classes solely for how something should look and the new classes for specific css for each section.

Added Google Analytics:
    I did this through the Firebase console and just adding a few lines of code to the pre-existing firebase script for the website. The purpose this serves is to track how many users my website has and how user activity varies over time.